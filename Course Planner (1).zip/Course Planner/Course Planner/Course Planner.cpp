// Course Planner.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>
#include <algorithm>
#include <vector>
#include <fstream>
#include <cstdlib>
#include <iomanip>
#include <sstream>
using namespace std;


///I could not figure out how to load data from a file and not matter what I tried on every type of database it did not work. Instead I loaded the databases from the strings containing the course information so that the info can still be accessed.
template <typename S> ostream& operator<<(ostream& os, const vector<S>& vector)
{

    for (auto element : vector)
    {
        os << element << " ";
    }
    return os;
}

int main(int argc, char** argv)
{
    //Since I could not get the vector to pull the text from the classes.txt file I made the string of classes to pull from. When user enters choice 1 the string classes will load onto the vector userClasses. The other functions will not work unless this is exacuted first.
    string classes[] = { " CSCI100,Introduction to Computer Science\n", "CSCI101,Introduction to Programming in C++\n", "CSCI200,Data Structures\n", "CSCI300,Introduction to Algorithims\n", "CSCI301,Advanced Programming in C++\n", "CSCI350,Operating Systems\n", "CSCI400,Large Software Development\n", "MATH201,Discrete Mathematics\n" };
    string CSCI101prereq[] = {"CSCI100"};
    string CSCI200prereq[] = {"CSCI101"};
    string CSCI300prereq[] = {"CSCI200,MATH201"};
    string CSCI301prereq[] = {"CSCI101"};
    string CSCI350prereq[] = {"CSCI300"};
    string CSCI400prereq[] = {"CSCI301,CSCI350"};
    

    //Vector data structures storing class data as well as class prereq data
    vector<string>userClasses;
    vector<string>CSCI101;
    vector<string>CSCI200;
    vector<string>CSCI300;
    vector<string>CSCI301;
    vector<string>CSCI350;
    vector<string>CSCI400;
    

    string course;

    cout << "Welcome to the Course Planner!\n";
    //use while loop to determine the user input and give the appropriate output in response
    while (true)
    {
        //used to determine which function of the course planner the user wants to use
        int choice = 0;
        //used to determine which course the user would like to know about
        int course = 0;

        cout << "Please select from the options below:\n";
        cout << "-------------------------------------\n";
        cout << "1.Load Data Structure.\n";
        cout << "2.Print Course List.\n";
        cout << "3.Print Course.\n";
        cout << "9.Exit Course Planner.\n";
        cout << "-------------------------------------\n";

        cout << "Please enter your choice:";
        cin >> choice;

        cout << "\n";

        if (choice == 1)
        {
            //If user selects one all the databases are loaded from strings containing course names and information. Program will not give proper output unless 1 is selected first.
            userClasses.assign(classes, classes + 8);
            CSCI101.assign(CSCI101prereq, CSCI101prereq + 1);
            CSCI200.assign(CSCI200prereq, CSCI200prereq + 1);
            CSCI300.assign(CSCI300prereq, CSCI300prereq + 2);
            CSCI301.assign(CSCI301prereq, CSCI301prereq + 1);
            CSCI350.assign(CSCI350prereq, CSCI350prereq + 1);
            CSCI400.assign(CSCI400prereq, CSCI400prereq + 2);
            
            cout << "----------------------\n";
            cout << "Data Structure Loaded!\n";
            cout << "----------------------\n\n";

        }
        //choice 2 is to print out a sample schedule for the user to see the course layout. Prereqs are not included in schedule. 
        else if (choice == 2)
        {
            cout << "-----------------------------------------------\n";
            cout << "Here is a sample schedule:\n";
            cout << userClasses;
            cout << "----------------------------------------------\n\n";
        }
        //I could not figure out how to read from a file and how to find a specific course and its prereqs, so rather than nothing I made another while loop and numbered the courses corresponding to the course the user would like to know about.
        else if (choice == 3)
        {
            while (true)
            {
                cout << "Which course would you like information on?\n";
                cout << "------------------------------\n";
                cout << "1.CSCI101.\n";
                cout << "2.CSCI200.\n";
                cout << "3.CSCI300.\n";
                cout << "4.CSCI301.\n";
                cout << "5.CSCI350.\n";
                cout << "6.CSCI400.\n";
                cout << "7.MATH201.\n";
                cout << "8.Exit.\n";
                cout << "------------------------------\n";
                cout << "Please select number corresponding to course:\n\n";
                cin >> course;
                cout << "\n\n";
                if (course == 1)
                {
                    cout << "The prerequisite(s): " << CSCI101 << ".\n\n";
                }
                else if (course == 2)
                {
                    cout << "The prerequisite(s): " << CSCI200 << ".\n\n";
                }
                else if (course == 3)
                {
                    cout << "The prerequisite(s): " << CSCI300 << ".\n\n";
                }
                else if (course == 4)
                {
                    cout << "The prerequisite(s): " << CSCI301 << ".\n\n";
                }
                else if (course == 5)
                {
                    cout << "The prerequisite(s): " << CSCI350 << ".\n\n";
                }
                else if (course == 6)
                {
                    cout << "The prerequisite(s): " << CSCI350 << ".\n\n";
                }
                else if (course == 7)
                {
                    cout << "The prerequisite(s): " << CSCI350 << ".\n\n";
                }
                else if (course == 8)
                {
                    break;
                }
                
            }
        }
        else if (choice == 9)
        {
            cout << "Thank you for using the Course Planner!\n";
            break;
        }
        else
        {
            cout << choice << " is not a valid input. Please select from the listed options.";
        }

    }

    return 0;
}
